package com.example.demo;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.concurrent.Worker;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

public class TableViewController {

    private ObservableList<Workers> workersList = FXCollections.observableArrayList();

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private TableView<Workers> FactoryTable;

    @FXML
    private TableColumn<?,?> NameWorker;

    @FXML
    private TableColumn<?, ?> PostWorker;

    @FXML
    private TableColumn<?, ?> WorkShop;

    @FXML
    private TableColumn<?, ?> YearWorker;

    @FXML
    private Button comeWorker;

    @FXML
    private Button removeWorker;

    @FXML
    void initialize() {
        initData();

        NameWorker.setCellValueFactory(new PropertyValueFactory<>("NameWorker"));
        PostWorker.setCellValueFactory(new PropertyValueFactory<>("PostWorker"));
        YearWorker.setCellValueFactory(new PropertyValueFactory<>("YearWorker"));
        WorkShop.setCellValueFactory(new PropertyValueFactory<>("WorkShop"));

        FactoryTable.setItems(workersList);
    }
    private void initData(){
        workersList.add(new Workers("Банщиков Алексей Олегович",1980,"Технолог", "Котельный цех"));
        workersList.add(new Workers("Самарскй Егор Игоревич",1977,"Слесарь", "Котельный цех"));
    }

}







