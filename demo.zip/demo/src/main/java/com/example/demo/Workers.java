package com.example.demo;

public class Workers {
    private String NameWorker;
    private int YearWorker;
    private String PostWorker;
    private String WorkShop;

    public Workers(String nameWorker, int yearWorker, String postWorker, String workShop) {
        NameWorker = nameWorker;
        YearWorker = yearWorker;
        PostWorker = postWorker;
        WorkShop = workShop;
    }
    public Workers(){

    }

    public String getNameWorker() {
        return NameWorker;
    }

    public void setNameWorker(String NameWorker) {
        NameWorker = NameWorker;
    }

    public int getYearWorker() {
        return YearWorker;
    }

    public void setYearWorker(int yearWorker) {
        YearWorker = yearWorker;
    }

    public String getPostWorker() {
        return PostWorker;
    }

    public void setPostWorker(String postWorker) {
        PostWorker = postWorker;
    }

    public String getWorkShop() {
        return WorkShop;
    }

    public void setWorkShop(String workShop) {
        WorkShop = workShop;
    }
}
