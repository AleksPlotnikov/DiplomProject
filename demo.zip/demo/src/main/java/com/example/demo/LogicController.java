package com.example.demo;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;

public class LogicController {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;
    @FXML
    private TableView<?> FactoryTable;

    @FXML
    private TableColumn<String, String> BoilerFactory;

    @FXML
    private TableColumn<?, ?> SteamFactory;

    @FXML
    private TableColumn<?, ?> TurboFactory;

    @FXML
    private Button comeWorker;

    @FXML
    private Button removeWorker;

    @FXML
    void initialize() {



    }

}
